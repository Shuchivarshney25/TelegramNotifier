chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'newMessage') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'New Message',
      message: message.text
    });
  }
});

function fetchNewMessages() {
  fetch(`https://api.telegram.org/bot5980704458:AAHmZPdbz3WflMXZ8gWtMZxghhgMaqLptms/getUpdates`)
    .then(response => response.json())
    .then(data => {
      if (data.result && data.result.length > 0) {
        const latestMessage = data.result[data.result.length - 1];
        const text = latestMessage.message && latestMessage.message.text; // Check if 'message' property exists before accessing 'text'
        if (text) {
          chrome.runtime.sendMessage({ type: 'newMessage', text: text });
        }
      }
    })
    .catch(error => {
      console.error('Error fetching new messages:', error);
    });
}

