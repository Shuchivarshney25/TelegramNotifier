chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'init') {
    // Inject a script into the Telegram page to send new messages to the background script
    const script = document.createElement('script');
    script.textContent = `
      setInterval(function() {
        const latestMessage = [...document.querySelectorAll('.im_message_text')].pop();
        if (latestMessage) {
          chrome.runtime.sendMessage({ type: 'newMessage', text: latestMessage.innerText });
        }
      }, 1000);
    `;
    document.body.appendChild(script);
  }
});

// Send an initialization message to the background script
chrome.runtime.sendMessage({ type: 'init' });

