chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'newMessage') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'New Message',
      message: message.text
    });
  }
});

